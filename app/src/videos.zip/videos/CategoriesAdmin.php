<?php 
    use SilverStripe\Admin\ModelAdmin;

    class CategorisACategoriesAdmindmin extends ModelAdmin {
        private static $menu_title = "Categories";
        private static $url_segment = 'categories';
        private static $show_in_menu = false;

        private static $managed_models = [
            ProductObjects::class
        ];
    }
?>